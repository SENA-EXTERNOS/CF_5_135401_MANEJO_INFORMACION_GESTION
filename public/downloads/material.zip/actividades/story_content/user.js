function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6DbMozSfy0I":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

