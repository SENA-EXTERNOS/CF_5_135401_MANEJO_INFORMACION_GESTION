function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5czTYMdjxhN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

